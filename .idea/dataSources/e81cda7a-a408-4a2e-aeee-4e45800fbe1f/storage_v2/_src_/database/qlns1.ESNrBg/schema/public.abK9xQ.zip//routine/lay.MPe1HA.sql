create function lay(mapb1 character varying)
    returns TABLE(manv character varying, hoten character varying, mapb character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY 
		select nv.manv, nv.hoten, nv.mapb
		from nhanvien nv
		where nv.mapb = mapb1
		order by random() limit 3;
END;
$$;

alter function lay(varchar) owner to postgres;

