create function curs() returns refcursor
    language plpgsql
as
$$
declare
    curs cursor for select mapb from phongban;
begin
    open curs;
   -- fetch curs into store;
    loop
    exit when not found;
        select nv.manv, nv.hoten, nv.mapb
		from nhanvien nv
		where nv.mapb = curs
		order by random() limit 3;
    end loop;
    close curs;
end
$$;

alter function curs() owner to postgres;

