create function update_number_employees_male() returns integer
    language plpgsql
as
$$
BEGIN
	ALTER TABLE phongban ADD COLUMN number_employees_male integer ;
    UPDATE phongban pb 
    SET number_employees_male = (select count(*) from nhanvien where mapb = pb.mapb and gioitinh = 'M');
    --UPDATE phongban pb 
    --SET number_employees_female = (select count(*) from nhanvien where mapb = pb.mapb and gioitinh = 'F'); 
    return number_employees_male;    
END;
$$;

alter function update_number_employees_male() owner to postgres;

