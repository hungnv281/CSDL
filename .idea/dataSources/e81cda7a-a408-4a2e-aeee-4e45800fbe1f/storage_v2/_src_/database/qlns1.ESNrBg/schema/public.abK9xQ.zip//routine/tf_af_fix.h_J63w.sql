create function tf_af_fix() returns trigger
    language plpgsql
as
$$
BEGIN
update luong
set luongcb = luongcb*1.1
where matdhv = NEW.matdhv;
RETURN NEW;
END;
$$;

alter function tf_af_fix() owner to postgres;

