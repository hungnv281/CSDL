create function update_number_employee() returns integer
    language plpgsql
as
$$
BEGIN
    UPDATE phongban pb 
    SET number_employees_male = (select count(*) from nhanvien where mapb = pb.mapb and gioitinh = 'M');
    UPDATE phongban pb 
    SET number_employees_female = (select count(*) from nhanvien where mapb = pb.mapb and gioitinh = 'F'); 
    return nbr;    
END;
$$;

alter function update_number_employee() owner to postgres;

