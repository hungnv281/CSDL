create function lay1()
    returns TABLE(manv character varying, hoten character varying, mapb character varying)
    language plpgsql
as
$$
declare pb phongban%rowtype;
BEGIN

	FOR pb IN SELECT mapb FROM phongban 
	LOOP
		return query select lay(customervar);
		return next ;--pb;
	END LOOP;
END;
$$;

alter function lay1() owner to postgres;

